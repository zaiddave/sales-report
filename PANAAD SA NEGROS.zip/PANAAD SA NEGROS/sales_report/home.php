<?php
session_start();
require_once('db_con/connect.php');
if(isset($_SESSION['id'])=="" ) {
  header("location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	
	<?php include('meta.php') ?>

	<title>Home</title>

	<?php include('link.php') ?>
	
</head>
<body>

	<nav class="navbar navbar-default">
	  <div class="container-fluid">
	    <!-- Brand and toggle get grouped for better mobile display -->
	    <div class="navbar-header">
	      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
	        <span class="sr-only">Toggle navigation</span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	      </button>
	      <a class="navbar-brand" href="#"><img src="image/peso.png" height="25px" width="25px"></a>
	    </div>

	    <!-- Collect the nav links, forms, and other content for toggling -->
	    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">     
	      <ul class="nav navbar-nav navbar-right">
	        <li><a href="#home">Home</a></li>
	        <li><a href="#lgu">LGU</a></li>
	        <li><a href="#overview">Sales Report</a></li>
	        <li><a href="logout.php">Log out</a></li>
	      </ul>
	    </div><!-- /.navbar-collapse -->
	  </div><!-- /.container-fluid -->
	</nav>
	
	<div class="container-fluid parallax" id="home">
		<center>
		<div class="row" style="margin-top: 50px;">
			<img class="img-responsive" src="image/panaad1.png">
			<img class="img-responsive" src="image/trade.png">			
		</div>
		</center>
	</div>
	
	<div class="container-fluid" id="lgu">
		<center><h1 class="h1-big txt-black"><strong>LGU</strong></h1></center>	
				
		<div class="well row ">
			<a href="bacolod.php">
			<div class="col-xs-12 col-md-12 lgu-5">
				<center><h3 class="h1-p"><strong>BACOLOD</strong></h3></center>
			</div>
			</a>
			<a href="bago.php">
			<div class="col-xs-12 col-md-2 lgu-1">
				<center><h3 class="h1-p"><strong>BAGO</strong></h3></center>
			</div>
			</a>
			<a href="binalbagan.php">
			<div class="col-xs-12 col-md-2 lgu-1">
				<center><h3 class="h1-p"><strong>BINALABAGAN</strong></h3></center>
			</div>
			</a>
			<a href="cadiz.php">
			<div class="col-xs-12 col-md-2 lgu-1">
				<center><h3 class="h1-p"><strong>CADIZ</strong></h3></center>
			</div>
			</a>
			<a href="calatrava.php">
			<div class="col-xs-12 col-md-2 lgu-1">
				<center><h3 class="h1-p"><strong>CALATRAVA</strong></h3></center>
			</div>
			</a>
			<a href="candoni.php">
			<div class="col-xs-12 col-md-2 lgu-1">
				<center><h3 class="h1-p"><strong>CANDONI</strong></h3></center>
			</div>
			</a>
			<a href="cauayan.php">
			<div class="col-xs-12 col-md-2 lgu-1">
				<center><h3 class="h1-p"><strong>CAUAYAN</strong></h3></center>
			</div>
			</a>
		</div>
		<div class="well row ">			
			<a href="don_salvador.php">
			<div class="col-xs-12 col-md-2 lgu-2">
				<center><h3 class="h1-p"><strong>DON SALVADOR</strong></h3></center>
			</div>
			</a>
			<a href="eb_magalona.php">
			<div class="col-xs-12 col-md-2 lgu-2">
				<center><h3 class="h1-p"><strong>E.B. MAGALONA</strong></h3></center>
			</div>
			</a>
			<a href="himamaylan.php">
			<div class="col-xs-12 col-md-2 lgu-2">
				<center><h3 class="h1-p"><strong>HIMAMAYLAN</strong></h3></center>
			</div>
			</a>
			<a href="hinigaran.php">
			<div class="col-xs-12 col-md-2 lgu-2">
				<center><h3 class="h1-p"><strong>HINIGARAN</strong></h3></center>
			</div>
			</a>
			<a href="hinobaan.php">
			<div class="col-xs-12 col-md-2 lgu-2">
				<center><h3 class="h1-p"><strong>HINOBAAN</strong></h3></center>
			</div>
			</a>
			<a href="ilog.php">
			<div class="col-xs-12 col-md-2 lgu-2">
				<center><h3 class="h1-p"><strong>ILOG</strong></h3></center>
			</div>
			</a>
		</div>
		<div class="well row ">			
			<a href="isabela.php">
			<div class="col-xs-12 col-md-2 lgu-3">
				<center><h3 class="h1-p"><strong>ISABELA</strong></h3></center>
			</div>
			</a>
			<a href="kabankalan.php">
			<div class="col-xs-12 col-md-2 lgu-3">
				<center><h3 class="h1-p"><strong>KABANKALAN</strong></h3></center>
			</div>
			</a>
			<a href="la_carlota.php">
			<div class="col-xs-12 col-md-2 lgu-3">
				<center><h3 class="h1-p"><strong>LA CARLOTA</strong></h3></center>
			</div>
			</a>
			<a href="la_castellana.php">
			<div class="col-xs-12 col-md-2 lgu-3">
				<center><h3 class="h1-p"><strong>LA CASTELLANA</strong></h3></center>
			</div>
			</a>
			<a href="manapla.php">
			<div class="col-xs-12 col-md-2 lgu-3">
				<center><h3 class="h1-p"><strong>MANAPLA</strong></h3></center>
			</div>
			</a>
			<a href="moises_padilla.php">
			<div class="col-xs-12 col-md-2 lgu-3">
				<center><h3 class="h1-p"><strong>MOISES PADILLA</strong></h3></center>
			</div>
			</a>
		</div>
		<div class="well row ">		
			<a href="murcia.php">	
			<div class="col-xs-12 col-md-2 lgu-4">
				<center><h3 class="h1-p"><strong>MURCIA</strong></h3></center>
			</div>
			</a>
			<a href="pontevedra.php">
			<div class="col-xs-12 col-md-2 lgu-4">
				<center><h3 class="h1-p"><strong>PONTEVEDRA</strong></h3></center>
			</div>
			</a>
			<a href="pulupandan.php">
			<div class="col-xs-12 col-md-2 lgu-4">
				<center><h3 class="h1-p"><strong>PULUPANDAN</strong></h3></center>
			</div>
			</a>
			<a href="sagay.php">
			<div class="col-xs-12 col-md-2 lgu-4">
				<center><h3 class="h1-p"><strong>SAGAY</strong></h3></center>
			</div>
			</a>
			<a href="san_enrique.php">
			<div class="col-xs-12 col-md-2 lgu-4">
				<center><h3 class="h1-p"><strong>SAN ENRIQUE</strong></h3></center>
			</div>
			</a>
			<a href="san_carlos.php">
			<div class="col-xs-12 col-md-2 lgu-4">
				<center><h3 class="h1-p"><strong>SAN CARLOS</strong></h3></center>
			</div>
			</a>
		</div>
		<div class="well row">	
			<a href="silay.php">		
			<div class="col-xs-12 col-md-2 lgu-5">
				<center><h3 class="h1-p"><strong>SILAY</strong></h3></center>
			</div>
			</a>
			<a href="sipalay.php">
			<div class="col-xs-12 col-md-2 lgu-5">
				<center><h3 class="h1-p"><strong>SIPALAY</strong></h3></center>
			</div>
			</a>
			<a href="talisay.php">
			<div class="col-xs-12 col-md-2 lgu-5">
				<center><h3 class="h1-p"><strong>TALISAY</strong></h3></center>
			</div>
			</a>
			<a href="toboso.php">
			<div class="col-xs-12 col-md-2 lgu-5">
				<center><h3 class="h1-p"><strong>TOBOSO</strong></h3></center>
			</div>
			</a>
			<a href="valladolid.php">
			<div class="col-xs-12 col-md-2 lgu-5">
				<center><h3 class="h1-p"><strong>VALLADOLID</strong></h3></center>
			</div>
			</a>
			<a href="victorias.php">
			<div class="col-xs-12 col-md-2 lgu-5">
				<center><h3 class="h1-p"><strong>VICTORIAS</strong></h3></center>
			</div>
			</a>
		</div>
	</div>

	<div class="container-fluid" id="overview">
		<center>
			<h1 class="h1-big txt-black"><strong>SALES REPORT</strong></h1>
			<a href="sales_report.php"><img class="img-responsive" src="image/overview.jpg"></a>
		</center>
	</div>

	<?php include('script.php') ?>
</body>
</html>