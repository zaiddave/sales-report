  <?php
  $query = "SELECT DISTINCT s_year FROM l_product_sales WHERE s_lgu = 'E.B. Magalona' ORDER BY s_year DESC ";
  $fetch = mysql_query($query);
  ?>
<div class="modal fade" id="salesModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Select Event Date</h4>
      </div>
      <div class="modal-body">
      <button class="btn btn-success btn-sm" type="button" data-toggle="collapse" data-target="#saleCollapse" aria-expanded="false" aria-controls="saleCollapse">
        <span class="fa fa-plus"></span>
      </button>
      <br><br>
      <div class="collapse" id="saleCollapse">
        <div class="well">
          <form class="form-horizontal" method="post" action="eb_magalona_add_sales_modal_form.php" enctype="multipart/form-data">          
            <div class="form-group">
                <input class="form-control" type="hidden" name="lgu" id="lgu" value="E.B. Magalona">
            </div>
            <div class="form-group">
              <label for="saleName" class="col-sm-3 control-label">Product Name:</label>
              <div class="col-sm-9">
                <input class="form-control" type="text" name="productName" id="saleName" placeholder="Product Name" required="true" autocomplete="off">     
              </div>
            </div>
            <div class="form-group">
              <label for="saleQuantity" class="col-sm-3 control-label">Product Quantity:</label>
              <div class="col-sm-9">
                <input class="form-control" type="number" name="productQuantity" id="saleQuantity" placeholder="Product Quantity" required="true" autocomplete="off">     
              </div>
            </div>             
            <div class="form-group">
              <label for="saleyear" class="col-sm-3 control-label">Year:</label>    
              <div class="col-sm-9">
                <select class="form-control" id="saleyear" name="year" required="true">
                <option value="" selected="selected">Select Year</option>
                  <?php for( $i=2015; $i<=2100; $i++ ) { ?>                    
                    <option value="<?php echo $i?> "><?php echo $i?></option>
                  <?php } ?>
                </select>
              </div>          
            </div>
            <div class="form-group">
              <label for="saleDate" class="col-sm-3 control-label">Date:</label>
              <div class="col-sm-9">                
                <select class="form-control" id="saleDate" name="productDate" required="true" onchange="selectDay(this)">
                <option value="" selected="selected">Select Date</option>  
                <option value="April 22">April 22</option>
                <option value="April 23">April 23</option>
                <option value="April 24">April 24</option>
                <option value="April 25">April 25</option>
                <option value="April 26">April 26</option>
                <option value="April 27">April 27</option>
                <option value="April 28">April 28</option>
                <option value="April 29">April 29</option>
                <option value="April 30">April 30</option>
                </select>
              </div>
            </div>
            <input type="hidden" name="day" value="Event Day" id="day" class="form-control" readonly="true">
            <button type="submit" class="btn btn-default" value="save">Add</button>          
          </form>
        </div>
      </div>     
        <table id="sale_table_modal" class="table table-striped table-bordered" cellpadding="0" width="100%">
          <thead>
              <tr>
                <th><center>Event Year</center></th>
                <th><center>Event Day</center></th>
              </tr>
          </thead>
          <tbody>
           <?php
            while ($row = mysql_fetch_array($fetch)) {
              $year = mysql_real_escape_string($row['s_year']);
           ?>
            <tr>
              <td><center><?php echo $year?></center></td>        
              <td></td>                    
            </tr>                  
            <?php
            $query1 = "SELECT DISTINCT s_date FROM l_product_sales WHERE s_lgu = 'E.B. Magalona' AND s_year = '$year' ORDER BY s_date DESC ";
            $fetch1 = mysql_query($query1);
             while ($row1 = mysql_fetch_array($fetch1)) {
              $date = mysql_real_escape_string($row1['s_date']);
            $dayQuery = "SELECT s_day FROM l_product_sales WHERE s_lgu = 'E.B. Magalona' AND s_year = '$year' AND s_date = '$date' ";
            $row2 = mysql_fetch_array(mysql_query($dayQuery));

            ?>
            <tr>
              <td></td>
              <td><center><a href="eb_magalona_sales_list.php?year=<?php echo $year?>&date=<?php echo $row1['s_date']?>&day=<?php echo $row2['s_day']?> "><?php echo $row1['s_date']?></a></center></td>
            </tr>
            <?php } ?>
          <?php } ?>
          </tbody>
        </table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>