<?php
session_start();
require_once('db_con/connect.php');
if(isset($_SESSION['id'])=="" ) {
  header("location: index.php");
}
$year = $_GET['year'];
$query = "SELECT * FROM l_product_list WHERE p_year = '$year' AND p_lgu = 'Himamaylan' ";
$fetch = mysql_query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	
	<?php include('meta.php') ?>

	<title>Himamaylan</title>

	<?php include('link.php') ?>
	
</head>
<body>
	<nav class="navbar navbar-default">
	  <div class="container-fluid">
	    <!-- Brand and toggle get grouped for better mobile display -->
	    <div class="navbar-header">
	      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
	        <span class="sr-only">Toggle navigation</span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	      </button>
	      <a class="navbar-brand" href="himamaylan.php"><span><img style="margin-top: -7px;" src="image/peso.png" height="25px" width="25px"></span>&nbsp;HIMAMAYLAN: Product List</a>	      
	    </div>
	    <!-- Collect the nav links, forms, and other content for toggling -->
	    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">     	    
	      <ul class="nav navbar-nav navbar-right">
	        <li><a href="home.php">Home</a></li>
	        <li><a href="himamaylan.php">Himamaylan</a></li>
	        <li><a href="logout.php">Log out</a></li>
	      </ul>
	    </div><!-- /.navbar-collapse -->
	  </div><!-- /.container-fluid -->
	</nav>
	<div class="col-md-12">
		<?php
		  if(isset($_SESSION['result'])){
		    echo $_SESSION['result'];
		    unset($_SESSION['result']);
		  }
		?>
	</div>

	<div class="container-fluid">
		<div class="well col-md-3">
			<form class="form-horizontal" name="productForm" method="post" action="himamaylan_add_product_form.php" enctype="multipart/form-data" >
			<div class="form-group">
                <input class="form-control" type="hidden" name="lgu" id="lgu" value="Himamaylan">
            </div>
			<div class="form-group">
				<label for="productName" class="col-sm-3 control-label">Product Name:</label>
				<div class="col-sm-9">
					<input class="form-control" type="text" name="productName" id="productName" placeholder="Product Name" required="true" autocomplete="off">			
				</div>
			</div>			
			<div class="form-group">
				<label for="productType" class="col-sm-3 control-label">Category:</label>
				<div class="col-sm-9">				
					<select class="form-control" name="productType" id="productType" required="true">
						<option value="" selected="selected">Select Category</option>
						<option value="Home Accessory">Home Accessory</option>
						<option value="Personal Accessory">Personal Accessory</option>
						<option value="Furniture">Furniture</option>
						<option value="Food Pasalubong">Food Pasalubong</option>
					</select>
				</div>
			</div>
                
			<div class="form-group">
				<label for="productQuantity" class="col-sm-3 control-label">Product Quantity:</label>
				<div class="col-sm-9">
					<input class="form-control" type="number" name="productQuantity" id="productQuantity" placeholder="Product Quantity" autocomplete="off" required="true">			
				</div>
			</div>
			<div class="form-group">
				<label for="productPrice" class="col-sm-3 control-label">Product Price:</label>
				<div class="col-sm-9">
					<div class="input-group">
					<span class="input-group-addon">Php</span>
					<input class="form-control" type="text" name="productPrice" id="productPrice" placeholder="Product Price" autocomplete="off" required="true">	
					</div>
					<p><small>Avoid adding 'P' or Peso sign (e.g. P100.23).</small></p>
				</div>				
			</div>
			<input class="form-control" type="hidden" name="year" id="year" value="<?php echo $year ?>" autocomplete="off">  			  			
			<center><input type="submit" name="add" value="Add Product" class="btn btn-primary"></center>
		</form>			
		</div>	
		<div class="col-md-9">
			<table id="table_product" class="table table-striped table-bordered" cellpadding="0" width="100%">
          <thead>
              <tr>
                <th><center>Item</center></th>
                <th><center>Type</center></th>
                <th><center>Quantity</center></th>
                <th><center>Price</center></th>
                <th><center>Total Cost</center></th>
                <th><center>Edit</center></th>
              </tr>
          </thead>
          <tbody>
           <?php
            while ($row = mysql_fetch_array($fetch)) {              
           ?>
            <tr>
              <td><center><?php echo $row['p_item'] ?></center></td>              
              <td><center><?php echo $row['p_type']?></center></td> 
              <td><center><?php echo $row['p_quantity']?></center></td> 
              <td><center><?php echo $row['p_price']?></center></td> 
              <td><center><?php echo $row['p_cost']?></center></td> 
              <td><center>
              <a name="productupdate" data-toggle="modal" data-target="#updateProduct"
              data-update-id = "<?php echo $row['p_id']?>"
              data-item = "<?php echo $row['p_item']?>"
              data-quantity = "<?php echo $row['p_quantity']?>"
              data-price = "<?php echo $row['p_price']?>"
              data-year="<?php echo $year ?>" >Edit</a>
               | 
              <a name="productdelete" data-toggle="modal" data-target="#deleteProduct"
              data-year="<?php echo $year ?>"
              data-delete-id="<?php echo $row['p_id']?>" >Delete</a></center></td>
            </tr>                  
          <?php } ?>
          </tbody>
        </table>
		</div>
	</div>


	<?php include('script.php') ?>
</body>
</html>		

<?php include('himamaylan_product_update.php') ?>
<?php include('himamaylan_product_delete.php') ?>
