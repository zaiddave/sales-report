<?php
session_start();
require_once('db_con/connect.php');
if(isset($_SESSION['id'])=="" ) {
  header("location: index.php");
}
//function to sanitize values received from the form. Prevents SQL injection

	function clean($str){
		$str = @trim($str);
		if(get_magic_quotes_gpc()){
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

$id = clean($_POST['id']);
$year = clean($_POST['year']);
$item = clean($_POST['productName']);
$category = clean($_POST['productType']);
$quantity = clean($_POST['productQuantity']);
$price = clean($_POST['productPrice']);
$total_cost = $quantity * $price;

	
	$query = "UPDATE l_product_list SET p_item = '$item', p_type = '$category', p_quantity = '$quantity', p_price = '$price', p_cost = '$total_cost' WHERE p_id = '$id'  " ;

	mysql_query($query);

	$result = '<div class="alert alert-info" role="alert">Successfully updated <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	$_SESSION['result'] = $result;
	header('location:pontevedra_product_list.php?year='.$year);

?>