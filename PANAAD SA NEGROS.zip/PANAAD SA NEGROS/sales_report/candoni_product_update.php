<div class="modal fade" data-keyboard="false" data-backdrop="static" id="updateProduct" tabindex="-1" role="dialog" aria-labelledby="updateProduct" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" data-dismiss="modal" class="close" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="updateProduct"><center><strong>Update</strong></center></h4>
      </div>

      <div class="modal-body">     
      <form class="form-horizontal" method="post" action="candoni_product_update_form.php" enctype="multipart/form-data">
                <div style="margin-right:20px; margin-left:20px;">
                <input type="hidden" class="form-control" name="year">
                <div class="form-group">
                    <input type="hidden" class="form-control" name="id">
                </div>
                <div class="form-group">
                  <label for="productName" class="col-sm-3 control-label">Product Name:</label>
                  <div class="col-sm-9">
                    <input class="form-control" type="text" name="productName" id="updateName" placeholder="Product Name" required="true" autocomplete="off">      
                  </div>
                </div>      
                <div class="form-group">
                  <label for="productType" class="col-sm-3 control-label">Category:</label>
                  <div class="col-sm-9">        
                    <select class="form-control" name="productType" id="updateType" required="true">
                      <option value="" selected="selected">Select Category</option>
                      <option value="Home Accessory">Home Accessory</option>
                      <option value="Personal Accessory">Personal Accessory</option>
                      <option value="Furniture">Furniture</option>
                      <option value="Food Pasalubong">Food Pasalubong</option>
                    </select>
                  </div>
                </div>
                          
                <div class="form-group">
                  <label for="productQuantity" class="col-sm-3 control-label">Product Quantity:</label>
                  <div class="col-sm-9">
                    <input class="form-control" type="number" name="productQuantity" id="updateQuantity" placeholder="Product Quantity" autocomplete="off" required="true">      
                  </div>
                </div>
                <div class="form-group">
                  <label for="productPrice" class="col-sm-3 control-label">Product Price:</label>
                  <div class="col-sm-9">
                    <div class="input-group">
                    <span class="input-group-addon">Php</span>
                    <input class="form-control" type="text" name="productPrice" id="updatePrice" placeholder="Product Price" autocomplete="off" required="true"> 
                    </div>
                    <p><small>Avoid adding 'P' or Peso sign (e.g. P100.23).</small></p>
                  </div>
                </div>     

                <br>

                <div class="form-group modal-footer">
                    <input class="btn btn-primary col-sm-5 col-sm-offset-3" type="submit" value="Update">
                </div>
                </div>
              </form>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->