<?php
session_start();
require_once('db_con/connect.php');
if(isset($_SESSION['id'])=="" ) {
  header("location: index.php");
}

$year = 0;

if(isset($_SESSION['year'])){
	$year = $_SESSION['year'];
	unset($_SESSION['year']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	
	<?php include('meta.php') ?>

	<title>Sales Report</title>

	<?php include('link.php') ?>
	
</head>
<body>
	<nav class="navbar navbar-default">
	  <div class="container-fluid">
	    <!-- Brand and toggle get grouped for better mobile display -->
	    <div class="navbar-header">
	      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
	        <span class="sr-only">Toggle navigation</span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	      </button>
	      <a class="navbar-brand" href="#"><span><img style="margin-top: -7px;" src="image/peso.png" height="25px" width="25px"></span>&nbsp;Sales Report</a>	      
	    </div>
	  </div><!-- /.container-fluid -->
	</nav>

	<div class="container-fluid">	
		<form class="form-inline" method="post" action="event_year.php">
				<div class="input-group">
			      <select class="form-control" name="eventYear" id="eventYear" required="true">
				 	<option value="" selected="selected">Select Year</option>
	                  <?php for( $i=2015; $i<=2100; $i++ ) { ?>                    
	                <option value="<?php echo $i?> "><?php echo $i?></option>
	                  <?php } ?>
				 </select>
			      <span class="input-group-btn">
			        <button type="submit" name="submit" class="btn btn-default btn-sm">Go</button>	
			      </span>
			    </div><!-- /input-group -->				 			
		</form>	
		<br><br>
		<table id="table_product" class="table table-striped table-bordered" cellpadding="0" width="100%">
          <thead>
              <tr>
                <th><center>LGU</center></th>
                <th><center>April 22</center></th>
                <th><center>April 23</center></th>
                <th><center>April 24</center></th>
                <th><center>April 25</center></th>
                <th><center>April 26</center></th>
                <th><center>April 27</center></th>
                <th><center>April 28</center></th>
                <th><center>April 29</center></th>
                <th><center>April 30</center></th>
              </tr>
          </thead>
          <tbody>           
            <tr>
            	<td>Bacolod</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Bacolod' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Bacolod' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Bacolod' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Bacolod' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Bacolod' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Bacolod' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Bacolod' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Bacolod' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Bacolod' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr> 
            <tr>
            	<td>Bago</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Bago' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Bago' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Bago' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Bago' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Bago' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Bago' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Bago' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Bago' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Bago' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>       
            <tr>
            	<td>Binalbagan</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Binalbagan' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Binalbagan' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Binalbagan' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Binalbagan' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Binalbagan' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Binalbagan' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Binalbagan' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Binalbagan' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Bacolod' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>             
            <tr>
            	<td>Cadiz</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Cadiz' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Cadiz' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Cadiz' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Cadiz' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Cadiz' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Cadiz' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Cadiz' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Cadiz' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Cadiz' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>        
            <tr>
            	<td>Calatrava</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Calatrava' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Calatrava' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Calatrava' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Calatrava' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Calatrava' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Calatrava' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Calatrava' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Calatrava' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Calatrava' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>   
            <tr>
            	<td>Candoni</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Candoni' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Candoni' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Candoni' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Candoni' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Candoni' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Candoni' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Candoni' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Candoni' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Candoni' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>  
            <tr>
            	<td>Cauayan</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Cauayan' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Cauayan' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Cauayan' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Cauayan' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Cauayan' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Cauayan' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Cauayan' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Cauayan' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Cauayan' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>  
            <tr>
            	<td>Don Salvandor</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Don Salvandor' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Don Salvandor' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Don Salvandor' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Don Salvandor' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Don Salvandor' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Don Salvandor' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Don Salvandor' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Don Salvandor' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Don Salvandor' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr> 
            <tr>
            	<td>E.B. Magalona</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'E.B. Magalona' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'E.B. Magalona' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'E.B. Magalona' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'E.B. Magalona' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'E.B. Magalona' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'E.B. Magalona' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'E.B. Magalona' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'E.B. Magalona' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'E.B. Magalona' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>   
            <tr>
            	<td>Himamaylan</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Himamaylan' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Himamaylan' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Himamaylan' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Himamaylan' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Himamaylan' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Himamaylan' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Himamaylan' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Himamaylan' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Himamaylan' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>        
            <tr>
            	<td>Hinigaran</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Hinigaran' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Hinigaran' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Hinigaran' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Hinigaran' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Hinigaran' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Hinigaran' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Hinigaran' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Hinigaran' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Hinigaran' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>  
            <tr>
            	<td>Hinobaan</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Hinobaan' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Hinobaan' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Hinobaan' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Hinobaan' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Hinobaan' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Hinobaan' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Hinobaan' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Hinobaan' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Hinobaan' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>     
            <tr>
            	<td>Ilog</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Ilog' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Ilog' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Ilog' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Ilog' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Ilog' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Ilog' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Ilog' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Ilog' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Ilog' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>         
            <tr>
            	<td>Isabela</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Isabela' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Isabela' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Isabela' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Isabela' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Isabela' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Isabela' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Isabela' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Isabela' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Isabela' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>    
            <tr>
            	<td>Kabankalan</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Kabankalan' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Kabankalan' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Kabankalan' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Kabankalan' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Kabankalan' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Kabankalan' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Kabankalan' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Kabankalan' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Kabankalan' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>  
            <tr>
            	<td>La Carlota</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'La Carlota' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'La Carlota' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'La Carlota' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'La Carlota' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'La Carlota' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'La Carlota' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'La Carlota' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'La Carlota' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'La Carlota' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>    
            <tr>
            	<td>La Castellana</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'La Castellana' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'La Castellana' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'La Castellana' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'La Castellana' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'La Castellana' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'La Castellana' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'La Castellana' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'La Castellana' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'La Castellana' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>     
            <tr>
            	<td>Manapla</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Manapla' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Manapla' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Manapla' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Manapla' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Manapla' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Manapla' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Manapla' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Manapla' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Manapla' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>   
            <tr>
            	<td>Moises Padilla</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Moises Padilla' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Moises Padilla' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Moises Padilla' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Moises Padilla' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Moises Padilla' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Moises Padilla' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Moises Padilla' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Moises Padilla' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Moises Padilla' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>       
            <tr>
            	<td>Murcia</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Murcia' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Murcia' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Murcia' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Murcia' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Murcia' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Murcia' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Murcia' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Murcia' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Murcia' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>      
            <tr>
            	<td>Pontevedra</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Pontevedra' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Pontevedra' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Pontevedra' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Pontevedra' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Pontevedra' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Pontevedra' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Pontevedra' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Pontevedra' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Pontevedra' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>        
            <tr>
            	<td>Pulupandan</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Pulupandan' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Pulupandan' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Pulupandan' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Pulupandan' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Pulupandan' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Pulupandan' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Pulupandan' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Pulupandan' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Pulupandan' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>       
            <tr>
            	<td>Sagay</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Sagay' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Sagay' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Sagay' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Sagay' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Sagay' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Sagay' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Sagay' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Sagay' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Sagay' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>   
            <tr>
            	<td>San Enrique</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'San Enrique' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'San Enrique' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'San Enrique' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'San Enrique' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'San Enrique' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'San Enrique' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'San Enrique' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'San Enrique' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'San Enrique' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>   
            <tr>
            	<td>San Carlos</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'San Carlos' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'San Carlos' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'San Carlos' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'San Carlos' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'San Carlos' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'San Carlos' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'San Carlos' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'San Carlos' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'San Carlos' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>                                                                                                                     <tr>
            	<td>Silay</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Silay' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Silay' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Silay' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Silay' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Silay' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Silay' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Silay' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Silay' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Silay' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>  
            <tr>
            	<td>Sipalay</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Sipalay' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Sipalay' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Sipalay' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Sipalay' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Sipalay' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Sipalay' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Sipalay' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Sipalay' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Sipalay' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>   
            <tr>
            	<td>Talisay</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Talisay' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Talisay' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Talisay' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Talisay' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Talisay' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Talisay' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Talisay' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Talisay' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Talisay' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>   
            <tr>
            	<td>Toboso</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Toboso' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Toboso' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Toboso' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Toboso' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Toboso' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Toboso' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Toboso' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Toboso' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Toboso' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>        
            <tr>
            	<td>Valladolid</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Valladolid' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Valladolid' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Valladolid' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Valladolid' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Valladolid' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Valladolid' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Valladolid' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Valladolid' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Valladolid' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>
            <tr>
            	<td>Victorias</td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Victorias' AND t_day = 'Day 1' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Victorias' AND t_day = 'Day 2' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Victorias' AND t_day = 'Day 3' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Victorias' AND t_day = 'Day 4' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Victorias' AND t_day = 'Day 5' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Victorias' AND t_day = 'Day 6' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Victorias' AND t_day = 'Day 7' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Victorias' AND t_day = 'Day 8' AND t_year = '$year' ";
				$fech = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            	<td><?php
				$query = "SELECT t_total FROM total_overview WHERE t_lgu = 'Victorias' AND t_day = 'Day 9' AND t_year = '$year' ";
				$fetch = mysql_query($query) or die(mysql_error());
				$row = mysql_fetch_array($fetch);
				echo $row['t_total'];
				?></td>
            </tr>                                                                                                                                                                                                                                                                                                           
          </tbody>
        </table>
	</div>


	<?php include('script.php') ?>
</body>
</html>		

<?php include('bago_product_update.php') ?>
<?php include('bago_product_delete.php') ?>
