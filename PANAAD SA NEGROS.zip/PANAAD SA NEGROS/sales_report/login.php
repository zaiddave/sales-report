<?php
session_start();
require_once('db_con/connect.php');

//function to sanitize values received from the form. Prevents SQL injection

	function clean($str){
		$str = @trim($str);
		if(get_magic_quotes_gpc()){
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

//sanitize the POST values

$user = clean($_POST['userName']);
$pwd = clean($_POST['userPassword']);



	$query = "SELECT * FROM  admin WHERE a_user = '$user' && a_pwd = md5('$pwd') ";
	$result = mysql_query($query) or die(mysql_error());
	

	if($result) {
		//check if username and password exist
		if(mysql_num_rows($result) > 0) {

		
		$info = mysql_fetch_array($result) or die(mysql_error());
		$_SESSION['id'] = $info['a_id'];
		session_write_close();
		
		header('location:home.php');	
	}
		else	{	
		$result = '<div class="alert alert-danger" role="alert">Invalid username or password <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

		$_SESSION['result'] = $result;
		header("location:index.php");

	}
	}
	else {
		$result = '<div class="alert alert-danger" role="alert">Invalid username or password <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

		$_SESSION['result'] = $result;
		header("location:index.php");
	}
?>