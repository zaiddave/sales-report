<?php
session_start();
require_once('db_con/connect.php');
if(isset($_SESSION['id'])=="" ) {
  header("location: index.php");
}
//function to sanitize values received from the form. Prevents SQL injection

	function clean($str){
		$str = @trim($str);
		if(get_magic_quotes_gpc()){
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

$lgu = clean($_POST['lgu']);
$item = clean($_POST['productName']);
$category = clean($_POST['productType']);
$quantity = clean($_POST['productQuantity']);
$price = clean($_POST['productPrice']);
$total_cost = $quantity * $price;
$year = clean($_POST['year']);

$validate = "SELECT * FROM l_product_list WHERE p_item = '$item' AND p_lgu = '$lgu' AND p_year = '$year' ";
$count = mysql_num_rows(mysql_query($validate));

if($count>0){
	$result = '<div class="alert alert-danger" role="alert">Product name already exist on the event year <b>'.$year.'</b> <span class="glyphicon glyphicon-exclamation-sign"></span> Please update your product instead.</div>';

	$_SESSION['result'] = $result;
	header('location:bacolod.php');	
}
else{
	
	$query = "INSERT INTO l_product_list (p_lgu, p_item, p_type, p_quantity, p_price, p_cost, p_year) VALUES ('$lgu', '$item', '$category', '$quantity', $price, '$total_cost', '$year')" ;

	mysql_query($query);

	$result = '<div class="alert alert-success" role="alert">Successfully added <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	$_SESSION['result'] = $result;
	header('location:bacolod.php');
}

?>