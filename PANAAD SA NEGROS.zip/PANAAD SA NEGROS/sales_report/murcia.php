<?php
session_start();
require_once('db_con/connect.php');
if(isset($_SESSION['id'])=="" ) {
  header("location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	
	<?php include('meta.php') ?>

	<title>Murcia</title>

	<?php include('link.php') ?>
	
</head>
<body>
	<nav class="navbar navbar-default">
	  <div class="container-fluid">
	    <!-- Brand and toggle get grouped for better mobile display -->
	    <div class="navbar-header">
	      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
	        <span class="sr-only">Toggle navigation</span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	      </button>
	      <a class="navbar-brand" href="#"><span><img style="margin-top: -7px;" src="image/peso.png" height="25px" width="25px"></span>&nbsp;MURCIA</a>	      
	    </div>

	    <!-- Collect the nav links, forms, and other content for toggling -->
	    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">     	    
	      <ul class="nav navbar-nav navbar-right">
	        <li><a href="home.php">Home</a></li>
	        <li><a href="logout.php">Log out</a></li>
	      </ul>
	    </div><!-- /.navbar-collapse -->
	  </div><!-- /.container-fluid -->
	</nav>
	<div class="col-md-12">
		<?php
		  if(isset($_SESSION['result'])){
		    echo $_SESSION['result'];
		    unset($_SESSION['result']);
		  }
		?>
	</div>

	<div class="container-fluid">
		<div class="well row">						
			<div class="col-xs-12 col-md-6 lgu-1" style="height: 500px;" onmouseover="show('productList');" onmouseout="hide('productList');">
				<center><h1 class="txt-box"><strong>Product List</strong></h1></center>
				<div class="col-md-12 black-transparent" id="productList" >
					<div class="row item" id="item">
					<center>
						<a data-toggle="modal" data-target="#productModal">
						<button class="btn btn-warning btn-sm" name="list" id="list">Product List</button>
						</a>
						<a data-toggle="modal" data-target="#salesModal">
						<button class="btn btn-success btn-sm" name="sales" id="sales">Daily Sales</button>
						</a>
					</center>
					</div>
					<p class="txt-white"><small><i>Click the 'Product List' to add, view, or update products. Or click the 'Daily Sales' to add purchased items.</i></small></p>
				</div>
			</div>
			<div class="col-xs-12 col-md-6 lgu-5" style="height: 500px;">
			<center><h1 class="txt-white"><strong>Details of Sales</strong></h1></center>
			<form class="form-inline" method="post" action="murcia_sales_details.php">
				<div class="form-group">
				 <label class="txt-white" for="eventYear">Event Year:</label>
				 <select class="form-control" name="eventYear" id="eventYear" required="true">
				 	<option value="" selected="selected">Select Year</option>
	                  <?php for( $i=2015; $i<=2100; $i++ ) { ?>                    
	                <option value="<?php echo $i?> "><?php echo $i?></option>
	                  <?php } ?>
				 </select>
				</div>
				<div class="form-group">
				 <label class="txt-white" for="eventDay">Event Day:</label>
				 <select class="form-control" name="eventDay" id="eventDay" required="true">
				 	<option value="" selected="selected">Select Day</option>                 
	                <option value="Day 1">Day 1</option>                  
	                <option value="Day 2">Day 2</option>                  
	                <option value="Day 3">Day 3</option>                  
	                <option value="Day 4">Day 4</option>                  
	                <option value="Day 5">Day 5</option>                  
	                <option value="Day 6">Day 6</option>                  
	                <option value="Day 7">Day 7</option>                  
	                <option value="Day 8">Day 8</option>                  
	                <option value="Day 9">Day 9</option>   
				 </select>
				</div>				
				 <button type="submit" name="submit" class="btn btn-default btn-sm">Go</button>				
			</form>			
			<p class="txt-white">
			<?php if(isset($_SESSION['year'])){
				echo $_SESSION['year']."<br>";
				unset($_SESSION['year']);
				}
				if(isset($_SESSION['day'])){
				echo $_SESSION['day'];
				unset($_SESSION['day']);
				}
				?>
			</p>
				<table class="table">
					<tbody>
						<tr>
							<td><p class="h1-p">Home Accessory:</p></td>
							<td></center><p class="h1-p"><?php
							if(isset($_SESSION['home'])){
								echo $_SESSION['home'];
								unset($_SESSION['home']);}?>							
							</p></center></td>
						</tr>
						<tr>
							<td><p class="h1-p">Personal Accessory:</p></td>
							<td></center><p class="h1-p"><?php
							if(isset($_SESSION['personal'])){
								echo $_SESSION['personal'];
								unset($_SESSION['personal']);}?>							
							</p></center></td>
						</tr>
						<tr>
							<td><p class="h1-p">Furniture:</p></td>
							<td></center><p class="h1-p"><?php
							if(isset($_SESSION['furniture'])){
								echo $_SESSION['furniture'];
								unset($_SESSION['furniture']);}?>							
							</p></center></td>
						</tr>
						<tr>
							<td><p class="h1-p">Food Pasalubong:</p></td>
							<td></center><p class="h1-p"><?php
							if(isset($_SESSION['food'])){
								echo $_SESSION['food'];
								unset($_SESSION['food']);}?>							
							</p></center></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>		
	</div>

	<?php include('script.php') ?>
</body>
</html>		
<?php include('murcia_product_modal.php') ?>
<?php include('murcia_sales_modal.php') ?>