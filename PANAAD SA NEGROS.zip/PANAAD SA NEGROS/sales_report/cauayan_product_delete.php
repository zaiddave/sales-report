<div class="modal fade" data-keyboard="false" data-backdrop="static" id="deleteProduct" tabindex="-1" role="dialog" aria-labelledby="deleteProduct" aria-hidden="true">
  <div class="modal-dialog modal-sm ">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" data-dismiss="modal" class="close" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="deleteProduct" ><center><strong>Confirm deletion?</strong></center></h4>
      </div>

      <div class="modal-body">     
      <p><center>Deleting this item cannot be undone.</center></p>
      <div class="form-group modal-footer">
      <form action="cauayan_delete_product_form.php"  method="post" enctype="multipart/form-data" class="form-horizontal">
      <input type="hidden" name="id">
      <input type="hidden" name="year" id="year" >
      <center>
      <a data-toggle="tooltip" data-placement="top" title="Confirm.">
      <button class="btn btn-success" type="submit"><span class="glyphicon glyphicon-ok"></span></button></a>&nbsp;&nbsp;
      <a data-toggle="tooltip" data-placement="top" title="Cancel.">
      <button class="btn btn-warning" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></button>
      </a></center>
      </form>
      </div>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->