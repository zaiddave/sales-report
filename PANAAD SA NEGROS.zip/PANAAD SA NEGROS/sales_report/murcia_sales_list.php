<?php
session_start();
require_once('db_con/connect.php');
if(isset($_SESSION['id'])=="" ) {
  header("location: index.php");
}

$year = $_GET['year'];
$date = $_GET['date'];
$day = $_GET['day'];
$query = "SELECT * FROM l_product_list WHERE p_year = '$year' AND p_lgu = 'Murcia' ORDER BY p_item ASC ";
$fetch = mysql_query($query);

$query1 = "SELECT * FROM l_product_sales WHERE s_date = '$date' AND s_lgu = 'Murcia' ORDER BY s_item ASC";
$fetch1 = mysql_query($query1);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	
	<?php include('meta.php') ?>

	<title>Murcia: Daily Sales as of <?php echo $date?></title>

	<?php include('link.php') ?>
	
</head>
<body>
	<nav class="navbar navbar-default">
	  <div class="container-fluid">
	    <!-- Brand and toggle get grouped for better mobile display -->
	    <div class="navbar-header">
	      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
	        <span class="sr-only">Toggle navigation</span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	      </button>
	      <a class="navbar-brand" href="#"><span><img style="margin-top: -7px;" src="image/peso.png" height="25px" width="25px"></span>&nbsp;MURCIA: Daily Sales</a>	      
	    </div>
	    <!-- Collect the nav links, forms, and other content for toggling -->
	    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">     	    
	      <ul class="nav navbar-nav navbar-right">
	        <li><a href="home.php">Home</a></li>
	        <li><a href="murcia.php">Murcia</a></li>
	        <li><a href="logout.php">Log out</a></li>
	      </ul>
	    </div><!-- /.navbar-collapse -->
	  </div><!-- /.container-fluid -->
	</nav>
	<div class="col-md-12">
		<?php
		  if(isset($_SESSION['result'])){
		    echo $_SESSION['result'];
		    unset($_SESSION['result']);
		  }
		?>
	</div>

	<div class="container-fluid">					
		<div class="well col-md-3">		
			<form class="form-horizontal" name="productForm" method="post" action="murcia_add_sales_form.php" enctype="multipart/form-data" >
			<div class="form-group">
                <input class="form-control" type="hidden" name="lgu" id="lgu" value="Murcia">
            </div>
			<div class="form-group">
				<label for="productName" class="col-sm-3 control-label">Product Name:</label>
				<div class="col-sm-9">
					<input class="form-control" type="text" name="productName" id="productName" placeholder="Product Name" required="true" autocomplete="off">			
				</div>
			</div>			
			<div class="form-group">
				<label for="productType" class="col-sm-3 control-label">Category:</label>
				<div class="col-sm-9">				
					<select class="form-control" name="productType" id="productType" required="true">
						<option value="" selected="selected">Select Category</option>
						<option value="Home Accessory">Home Accessory</option>
						<option value="Personal Accessory">Personal Accessory</option>
						<option value="Furniture">Furniture</option>
						<option value="Food Pasalubong">Food Pasalubong</option>
					</select>
				</div>
			</div>
                
			<div class="form-group">
				<label for="productQuantity" class="col-sm-3 control-label">Product Quantity:</label>
				<div class="col-sm-9">
					<input class="form-control" type="number" name="productQuantity" id="productQuantity" placeholder="Product Quantity" autocomplete="off" required="true">			
				</div>
			</div>
			<div class="form-group">
				<label for="productPrice" class="col-sm-3 control-label">Product Price:</label>
				<div class="col-sm-9">
					<div class="input-group">
					<span class="input-group-addon">Php</span>
					<input class="form-control" type="text" name="productPrice" id="productPrice" placeholder="Product Price" autocomplete="off" required="true">	
					</div>
					<p><small>Avoid adding 'P' or Peso sign (e.g. P100.23).</small></p>
				</div>				
			</div>
			<input class="form-control" type="hidden" name="year" id="year" value="<?php echo $year ?>" autocomplete="off">  		
			<input class="form-control" type="hidden" name="date" id="date" value="<?php echo $date ?>" autocomplete="off">  	  	
			<input class="form-control" type="hidden" name="day" id="day" value="<?php echo $day ?>" autocomplete="off">  	  			
			<center><input type="submit" name="add" value="Add Product" class="btn btn-primary"></center>
		</form>		
		</div>	
		<div class="col-md-9">
			<table id="table_modal" class="table table-striped table-bordered" cellpadding="0" width="100%">
          <thead>
              <tr>
                <th><center>Item</center></th>
                <th><center>Type</center></th>
                <th><center>Quantity</center></th>
                <th><center>Price</center></th>
                <th><center>Total Cost</center></th>
                <th><center>Edit</center></th>
              </tr>
          </thead>
          <tbody>
           <?php
            while ($row = mysql_fetch_array($fetch)) {              
           ?>
            <tr>
              <td><center><?php echo $row['p_item'] ?></center></td>              
              <td><center><?php echo $row['p_type']?></center></td> 
              <td><center><?php echo $row['p_quantity']?></center></td> 
              <td><center><?php echo $row['p_price']?></center></td> 
              <td><center><?php echo $row['p_cost']?></center></td> 
              <td><center>
              <a data-toggle="modal" data-target="#purchaseModal"
              data-purchase-id = "<?php echo $row['p_id']?>"
              data-lgu = "Murcia"
              data-item = "<?php echo $row['p_item']?>"
              data-year="<?php echo $year ?>"
              data-date="<?php echo $date ?>"
              data-day="<?php echo $day ?>" >Add to purchase</a></center></td>
            </tr>                  
          <?php } ?>
          </tbody>
        </table>
		</div>
	</div>

	<div class="well container-fluid">
	<center><span class="glyphicon glyphicon-collapse-down" data-toggle="collapse" data-target="#addCollapse" aria-expanded="false" aria-controls="collapseExample"></span></center>
		<div id="addCollapse" class="collapse col-md-12">
		<center><h1 class="h1-p txt-black"><strong>Daily Sales for the day: <?php echo $date?></strong></h1></center>
		<table id="table_product" class="table table-striped table-bordered" cellpadding="0" width="100%">
          <thead>
              <tr>
                <th><center>Item</center></th>
                <th><center>Type</center></th>
                <th><center>Quantity</center></th>
                <th><center>Price</center></th>
                <th><center>Total Cost</center></th>
                <th><center>Edit</center></th>
              </tr>
          </thead>
          <tbody>
           <?php
            while ($row1 = mysql_fetch_array($fetch1)) {              
           ?>
            <tr>
              <td><center><?php echo $row1['s_item'] ?></center></td>              
              <td><center><?php echo $row1['s_type']?></center></td> 
              <td><center><?php echo $row1['s_quantity']?></center></td> 
              <td><center><?php echo $row1['s_price']?></center></td> 
              <td><center><?php echo $row1['s_cost']?></center></td> 
              <td><center>
              <a name="productdelete" data-toggle="modal" data-target="#deleteSales"
              data-year="<?php echo $year ?>"
              data-date="<?php echo $date ?>"
              data-day="<?php echo $day ?>"
              data-delete-id="<?php echo $row1['s_id']?>" >Remove</a></center></td>
            </tr>                  
          <?php } ?>
          </tbody>
        </table>
		</div>
	</div>

	<?php include('script.php') ?>
</body>
</html>		

<?php include('murcia_sales_add_modal.php') ?>
<?php include('murcia_sales_delete.php')?>