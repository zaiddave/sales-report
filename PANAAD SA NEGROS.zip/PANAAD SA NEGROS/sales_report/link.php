<link rel="icon" href="image/peso.png">
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="assets/css/ie10-viewport-bug-workaround.css">
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
<!-- DataTables CSS -->
<link href="assets/datatables/css/jquery.dataTables.min.css" rel="stylesheet" >
<link href="assets/datatables/css/buttons.dataTables.min.css" rel="stylesheet" >
<link href="assets/datatables/css/dataTables.bootstrap.min.css" rel="stylesheet" >
<!-- Font Awesome CSS -->
<link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
<!--custom jquery ui min css for the calendar display in inputy text -->
<link href="assets/jquery-ui-1.11.4.custom/jquery-ui.min.css" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="style.css">