<?php
session_start();
require_once('db_con/connect.php');
if(isset($_SESSION['id'])!="" ) {
  header("location: home.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<?php include('meta.php') ?>
	<title>Login</title>
	<?php include('link.php') ?>
</head>
<body class="bg-body">
<div class="container-fluid">
<div class="row">
	<div class="col-md-offset-4 col-md-4 box-login">	
	<h1><center>Panaad sa Negros</center></h1>
	<h2><center><small class="txt-white">Trade Fair Exhibit</small></center></h2>
	<hr>
	<div class="col-md-12">
		<?php if(isset($_SESSION['result'])){
			echo $_SESSION['result'];
			unset($_SESSION['result']);
			}?>
	</div>
	<div class="col-md-12">
		<form class="form-horizontal" method="post" action="login.php" enctype="multipart/form-data">
			<div class="form-group">
				<label for="userName" class="control-label">Username:</label>
				<div class="col-md-12">
					<input type="text" name="userName" id="userName" placeholder="Username" class="form-control" autocomplete="off">
				</div>
			</div>
			<div class="form-group">
				<label for="userPassword" class="control-label">Password:</label>
				<div class="col-md-12">
					<input type="password" name="userPassword" id="userPassword" placeholder="Password" class="form-control">
				</div>
			</div>
			<button type="submit" class="btn btn-primary col-md-offset-4 col-md-4">Login</button>
			<br><br><br>
		</form>
	</div>
	</div>
</div>	
</div>
<br><br><br>
	<?php include('script.php') ?>
</body>
</html>