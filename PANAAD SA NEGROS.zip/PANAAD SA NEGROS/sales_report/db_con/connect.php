<?php
$host = "localhost";
$user = "root";
$pass = "" ;
$db = "sales_report";

$con = mysql_connect($host, $user, $pass) or die("Unable to connect to server!");
mysql_select_db($db, $con) or die("Database not found");
?>