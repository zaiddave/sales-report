<div class="modal fade" id="purchaseModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><center>Add Item Sale</center></h4>
      </div>
      <div class="modal-body">
      <form class="form-horizontal" method="post" action="candoni_sales_purchase_form.php" enctype="multipart/form-data">          
            <div class="form-group">
                <input class="form-control" type="hidden" name="lgu" id="lgu" value="Candoni">
            </div>
            <div class="form-group">
              <label for="saleName" class="col-sm-3 control-label">Product Name:</label>
              <div class="col-sm-9">
                <input class="form-control" type="text" name="productName" id="saleName" placeholder="Product Name" required="true" autocomplete="off">     
              </div>
            </div>
            <div class="form-group">
              <label for="saleQuantity" class="col-sm-3 control-label">Product Quantity:</label>
              <div class="col-sm-9">
                <input class="form-control" type="number" name="productQuantity" id="saleQuantity" placeholder="Product Quantity" required="true" autocomplete="off">     
              </div>
            </div>             
              <input type="hidden" name="year" id="saleYear">                    
              <input type="hidden" name="productDate" id="saleDate" placeholder="mm/dd/yyyy" required="true" autocomplete="off">
              <input type="hidden" id="day" name="day" required="true">
            <div class="modal-footer">
              <button type="submit" class="btn btn-success col-md-3 col-md-offset-4" value="save">Add</button>          
            </div>            
          </form>
      </div>
    </div>
  </div>
</div>