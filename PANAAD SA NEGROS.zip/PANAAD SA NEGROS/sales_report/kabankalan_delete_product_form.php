<?php

session_start();

require_once("db_con/connect.php");
if(isset($_SESSION['id'])=="" ) {
  header("location: index.php");
}

	function clean($str){
		$str = @trim($str);
		if(get_magic_quotes_gpc()){
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

//sanitize the POST values
	$id = clean($_POST['id']);	
	$year = clean($_POST['year']);
	$query = "DELETE FROM l_product_list WHERE p_id = $id" ;

	mysql_query($query) or die(mysql_error());

	$warning = '<div class="alert alert-warning" role="alert"><b>Delete</b> successful <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

    $_SESSION['result'] = $warning;
	header('location:kabankalan_product_list.php?year='.$year);
?>