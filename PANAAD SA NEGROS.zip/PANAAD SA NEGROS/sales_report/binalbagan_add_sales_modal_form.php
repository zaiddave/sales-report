<?php
session_start();
require_once('db_con/connect.php');
if(isset($_SESSION['id'])=="" ) {
  header("location: index.php");
}
//function to sanitize values received from the form. Prevents SQL injection

	function clean($str){
		$str = @trim($str);
		if(get_magic_quotes_gpc()){
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

$lgu = clean($_POST['lgu']);
$item = clean($_POST['productName']);
$quantity = clean($_POST['productQuantity']);
$year = clean($_POST['year']);
$date = clean($_POST['productDate']);
$day = clean($_POST['day']);

$priceQuery =" SELECT p_price, p_type  FROM l_product_list WHERE p_item = '$item' AND p_lgu = '$lgu' AND p_year = '$year' ";
$priceFetch = mysql_query($priceQuery);
$row = mysql_fetch_array($priceFetch);
$category = $row['p_type'];
$price = $row['p_price'];
$total_cost = $quantity * $price;

$validate = "SELECT * FROM l_product_list WHERE p_item = '$item' AND p_lgu = '$lgu' AND p_year = '$year' ";
$count = mysql_num_rows(mysql_query($validate));

if($count<=0){
	$result = '<div class="alert alert-danger" role="alert">Product name does not exist. Go to <b>\'Product List\'</b> and add an item before proceeding <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	$_SESSION['result'] = $result;
	header('location:binalbagan.php');	
}
else{
	
	$query = "INSERT INTO l_product_sales (s_lgu, s_item, s_type, s_quantity, s_price, s_cost, s_year, s_date, s_day) VALUES ('$lgu', '$item', '$category', '$quantity', $price, '$total_cost', '$year', '$date', '$day')" ;

	mysql_query($query);

	// Home Accessory Details
				$homQuery = "SELECT s_cost FROM l_product_sales WHERE s_type = 'Home Accessory' AND s_lgu = '$lgu' AND s_year = '$year' AND s_day = '$day' ";
				$homFetch = mysql_query($homQuery) or die(mysql_error());		
				for($hom=0;$hom<=mysql_num_rows($homFetch);$hom++){
					while($homRow = mysql_fetch_array($homFetch)){			
					$hom = $hom + $homRow['s_cost'];	
				}
				}
				

				// Personal Accessory Details
				$perQuery = "SELECT s_cost FROM l_product_sales WHERE s_type = 'Personal Accessory' AND s_lgu = '$lgu' AND s_year = '$year' AND s_day = '$day' ";
				$perFetch = mysql_query($perQuery) or die(mysql_error());		
				for($per=0;$per<=mysql_num_rows($perFetch);$per++){
					while($perRow = mysql_fetch_array($perFetch)){			
					$per = $per + $perRow['s_cost'];	
				}
				}
				

				// Furniture Details
				$furQuery = "SELECT s_cost FROM l_product_sales WHERE s_type = 'Furniture' AND s_lgu = '$lgu' AND s_year = '$year' AND s_day = '$day' ";
				$furFetch = mysql_query($furQuery) or die(mysql_error());		
				for($fur=0;$fur<=mysql_num_rows($furFetch);$fur++){
					while($furRow = mysql_fetch_array($furFetch)){			
					$fur = $fur + $furRow['s_cost'];	
				}
				}
				

				// Food Details
				$foodQuery = "SELECT s_cost FROM l_product_sales WHERE s_type = 'Food Pasalubong' AND s_lgu = '$lgu' AND s_year = '$year' AND s_day = '$day' ";
				$foodFetch = mysql_query($foodQuery) or die(mysql_error());		
				for($food=0;$food<=mysql_num_rows($foodFetch);$food++){
					while($foodRow = mysql_fetch_array($foodFetch)){			
					$food = $food + $foodRow['s_cost'];	
				}
				}

				$homtotal = $hom - 1;	
				$pertotal = $per - 1;	
				$furtotal = $fur - 1;	
				$foodtotal = $food - 1;
				$overall = $homtotal + $pertotal + $furtotal + $foodtotal;				


	$checkQuery = "SELECT * FROM total_overview WHERE t_lgu = '$lgu' AND t_year = '$year' AND t_day = '$day' ";
	$validate = mysql_num_rows(mysql_query($checkQuery));

	if($validate>0){
		$updateQuery = "UPDATE total_overview SET t_home = '$homtotal', t_personal = '$pertotal', t_furniture = '$furtotal', t_food = '$foodtotal', t_total = '$overall' WHERE t_lgu = '$lgu' AND t_year = '$year' AND t_day = '$day' ";
		mysql_query($updateQuery);
	
	$result = '<div class="alert alert-success" role="alert">Successfully added <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	$_SESSION['result'] = $result;
	header('location:binalbagan.php');
	}
	else{
		$insertQuery = "INSERT INTO total_overview (t_lgu, t_home, t_personal, t_furniture, t_food, t_year, t_day, t_total) VALUES ('$lgu', '$homtotal', '$pertotal', '$furtotal', '$foodtotal', '$year', '$day', '$overall')";
		mysql_query($insertQuery);
	
	$result = '<div class="alert alert-success" role="alert">Successfully added <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	$_SESSION['result'] = $result;
	header('location:binalbagan.php');
	}

	
}

?>